import { Text, View } from "react-native";

export default function Index() {
  return (
    <View className="flex-1 items-center justify-center bg-purple-300">
      <Text className="text-xl text-black">Hello World</Text>
    </View>
  );
}
